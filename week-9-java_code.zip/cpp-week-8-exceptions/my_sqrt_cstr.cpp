#include <iostream>  //std::std::cout std::std::endl std::std::cin
#include <cmath>     //sqrt
//#include <string>    //std:string
//#include <stdexcept> //std::exception
//using namespace std;

double my_sqrt(double n);

int main() {
	double n;
	std::cout << "Enter a positive number n:" << std::endl;
	std::cin >> n;
	
	try {
		std::cout << my_sqrt(n) << std::endl;
	}
	catch (const char*& e) {
		std::cout << "exception thrown and caught (char*): " << e << std::endl;
	}
	
	std::cout << "bye." << std::endl;
	
	return 0;
}


double my_sqrt(double n) {
	if(n<0) {
		throw "negative number";
	}
	return sqrt(n);
}


/* Output:
	$ ./prog
	Enter a positive number n:
	-1
	exception thrown and caught (char*): negative number
	bye.
*/
