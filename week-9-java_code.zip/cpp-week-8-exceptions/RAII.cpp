class class_name {
	public:
		class_name(); //Constructor
		//acquires the resource and throws exceptions on errors in handling it
		
		~class_name(); //Destructor
		//releases the resource, removing the need for an explicit clean-up on the user's end
		
		//...

};
