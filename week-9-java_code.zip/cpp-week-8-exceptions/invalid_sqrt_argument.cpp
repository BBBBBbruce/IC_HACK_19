class invalid_sqrt_argument : public invalid_argument {
    public:
        invalid_sqrt_argument(const string& what) :
            invalid_argument(what) {}
};
