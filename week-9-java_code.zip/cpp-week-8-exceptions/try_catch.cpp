//try-catch block
try{
	//functions calls
	//...
	}
	catch(const exception_type& e){
		cout << "exception caught" << e (or e.function()) << ...
		//processing
		//...
	}	
