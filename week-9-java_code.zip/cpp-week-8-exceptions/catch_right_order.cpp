   catch(const invalid_sqrt_argument& e){
        cout << "unsuccessful sqrt computation: " << e.what() << endl;
    }
    catch(const out_of_range& e){
        cout << "index not suitable: " << e.what() << endl;
    }
    catch(const logic_error& e){
        cout << "some other logic error: " << e.what() << endl;
    }
    catch(const exception& e){
        cout << "some other exception" << endl;
    }
