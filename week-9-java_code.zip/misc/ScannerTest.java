import java.util.Scanner;

public class ScannerTest {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter your name: ");
		String name = scanner.next();
		
		System.out.print("Enter your age: ");
		int age = scanner.nextInt();
		
		System.out.println("\nname=" + name + ", age=" + age);
	}
}

/* Output:
	$ java ScannerTest
	Enter your name: Java
	Enter your age: 23

	name=Java, age=23
*/


