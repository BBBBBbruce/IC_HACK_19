public class NullPointerTest {
	public static void main(String[] args) {
		try {
			String s = null;
			s.length();
			/*Point p = null;
			p.getX();*/
		}
		catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
		
		System.out.println("\nEnd.");
	}
}

/* Output:
	$ java NullPointerTest
	java.lang.NullPointerException
	java.lang.NullPointerException
			at NullPointerTest.main(NullPointerTest.java:5)

	End.
*/