import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;

public class IOTest {
	
	public static void main(String[] args) {
		try {
			File file = new File("input.txt");
			FileReader fr = new FileReader(file); 
		}
		catch (FileNotFoundException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		
		System.out.println("\nEnd.");
	}
}

/* Output:
	$ java IOTest
	java.io.FileNotFoundException: input.txt (The system cannot find the file specified)
	java.io.FileNotFoundException: input.txt (The system cannot find the file specified)
			at java.io.FileInputStream.open0(Native Method)
			at java.io.FileInputStream.open(FileInputStream.java:195)
			at java.io.FileInputStream.<init>(FileInputStream.java:138)
			at java.io.FileReader.<init>(FileReader.java:72)
			at IOTest.main(IOTest.java:10)

	End.
*/