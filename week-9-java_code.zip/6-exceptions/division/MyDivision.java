public class MyDivision {
	
	public static double divide(double num, double denum) throws DivisionByZeroException {
		if(denum == 0) {
			throw new DivisionByZeroException();
		}
		
		return num/denum;
	}
}