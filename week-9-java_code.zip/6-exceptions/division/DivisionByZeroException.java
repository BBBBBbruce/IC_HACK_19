//https://docs.oracle.com/javase/8/docs/api/?java/lang/ArithmeticException.html

public class DivisionByZeroException extends ArithmeticException {
}
