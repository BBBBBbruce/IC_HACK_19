public class MyDivisionTest {
	
	public static void main(String[] args) {
		int num = 5;
		int denum = 0;
		
		try {
			MyDivision.divide(num, denum);
		}
		catch(DivisionByZeroException e) {
			System.out.println(e);
			e.printStackTrace();	
		}
		
		System.out.println("\nEnd.");
	}
}

/* Output:
	$ java MyDivisionTest
	DivisionByZeroException
	DivisionByZeroException
			at MyDivision.divide(MyDivision.java:5)
			at MyDivisionTest.main(MyDivisionTest.java:8)

	End.
*/