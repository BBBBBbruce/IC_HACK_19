public class IndexBoundTest {
	public static void main(String[] args) {
		int num[] = {1, 2, 3, 4};
		
		try {
			System.out.println(num[5]);
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Exception thrown  :" + e);
			e.printStackTrace();
		}
		
		System.out.println("\nEnd.");
	}
}

/* Output:
	$ java IndexBoundTest
	Exception thrown  :java.lang.ArrayIndexOutOfBoundsException: 5
	java.lang.ArrayIndexOutOfBoundsException: 5
			at IndexBoundTest.main(IndexBoundTest.java:6)
			
	End.
*/