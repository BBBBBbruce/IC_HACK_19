public class HelloWorld {
	
	public static void main(String[] args) {
		System.out.println("Hello world!");
	}
}

/* Output:
	$ javac helloworld.java
	helloworld.java:1: error: class HelloWorld is public, should be declared in a file named HelloWorld.java
	public class HelloWorld {
		   ^
	1 error
*/