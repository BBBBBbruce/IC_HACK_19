public class HelloWorld {
	
	public static void main(String[] args) {
		System.out.println("Hello world!");
	}
}

/* Output:
	$ ls
	HelloWorld.java
	$ javac HelloWorld.java
	$ ls
	HelloWorld.class  HelloWorld.java
	$ ./HelloWorld.class
	-bash: ./HelloWorld.class: cannot execute binary file: Exec format error
	$ java HelloWorld
	Hello world!
*/

//copy HelloWorld.class to another machine/architecture (e.g Linux/Ubuntu), and run it (portablity)
//if same JVM, no need to recompile the sources

/*
	$ java -version
	java version "1.8.0_131"
*/
