public class LabeledPointTest {
	
	public static void main(String[] args) {
		//Point origin = new Point();
		Point p = new Point(1, 2);
		System.out.println(p);
		
		LabeledPoint lp = new LabeledPoint(2, 3, "A");
		System.out.println(lp.toString());
		System.out.println(lp);
		
		lp.setLabel("B");
		System.out.println(lp);
	}
}

/* Output:
	$ java LabeledPointTest
	(1.0, 2.0)
	A(2.0, 3.0)
	A(2.0, 3.0)
	B(2.0, 3.0)
*/