public class LabeledPoint extends Point { //inheritance
	private String label;
	
	public LabeledPoint() {
		super(); //call of the base class constructor
		label = "";
	}
	
	public LabeledPoint(double x, double y, String label) {
		super(x, y); //call of the base class constructor
		this.label = label;
	}	
	
	public String getLabel() {
		return label;
	}
	
	public void setLabel(String label) {
		this.label = label;
	}
	
	//method overriding
	public String toString() {
		return(label + super.toString());
	}
}