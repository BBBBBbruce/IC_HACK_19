public class Triangle {
	private Point p1;
	private Point p2;
	private Point p3;
	
	public Triangle(Point p1, Point p2, Point p3) {
		this.p1 = p1;
		this.p2 = p2;
		this.p3 = p3;
	}
	
	public Triangle(double x1, double y1, double x2, double y2, double x3, double y3) {
		this.p1 = new Point(x1, y1);
		this.p3 = new Point(x2, y2);
		this.p3 = new Point(x3, y3);
	}
	
	//getters
	//...
	
	//setters
	//...
	
	public void translate(double deltaX, double deltaY) {
		p1.translate(deltaX, deltaY);
		p2.translate(deltaX, deltaY);
		p3.translate(deltaX, deltaY);
	}
	
	public String toString() {
		return("Triangle[" + p1 + "->" + p2 + "->" + p3 + "]");
	}
		
}