import java.lang.Math; //for sqrt() and pow()
//API: https://docs.oracle.com/javase/10/docs/api/java/lang/Math.html

public class Point {
	//Fields (or UML/Attributes) (C++/Variables)
	protected double x;
	protected double y;
		
	//Constructors
	public Point() {
		this(0.0, 0.0);
	}
	
	public Point(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	//Methods (or UML/Operations) (C++/Functions)
	public double getX() {
		return x; //or return this.x;
	}
	
	public void setX(double x)  {
		this.x = x;
	}
	
	public double getY() {
		return y; //or return this.y;
	}
	
	public void setY(double y)  {
		this.y = y;
	}
	
	public void translate(double deltaX, double deltaY) {
		x += deltaX;
		y += deltaY;
	}
	
	public double distanceTo(Point other) {
		double deltaX = this.x - other.x;
		double deltaY = this.y - other.y;
		double distance = Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaY, 2));
		
		return(distance);
	}
	
	public double distanceToOrigin() {
		Point origin = new Point(0, 0);
		return distanceTo(origin); //or this.distanceTo(origin)
	}
	
	public String toString() {
		return("(" + x + ", " + y + ")");
	}
}