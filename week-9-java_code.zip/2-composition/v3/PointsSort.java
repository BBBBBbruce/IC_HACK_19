//import java.util.*; //imports all classes/interfaces in the package java.util

import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class PointsSort {
	public static void main(String[] args) {
		List<Point> points = new ArrayList<Point>();
		Scanner input = new Scanner(System.in);
		
		//get the points coordinates from the User
		for(int i = 0; i < 3; i++) {
			double x = input.nextDouble();
			double y = input.nextDouble();
			points.add(new Point(x,y));
		}

		for(int i = 0; i< 3; i++) {
			System.out.println(points.get(i));
		}

		//sort the list of points
		Collections.sort(points); 
		
		//check the result
		System.out.println();
		Iterator itr = points.iterator(); //use of iterators
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}

/* Output:
	$ java PointsSort 
	5
	4
	1
	2
	0
	1
	(5.0, 4.0)
	(1.0, 2.0)
	(0.0, 1.0)

	(0.0, 1.0)
	(1.0, 2.0)
	(5.0, 4.0)
*/
