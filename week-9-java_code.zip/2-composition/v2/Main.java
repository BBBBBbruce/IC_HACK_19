public class Main {
	public static void main(String[] args) {
		Point p1 = new Point();
		Point p2 = new Point(0, 1);
		Point p3 = new Point(1, 0);
		
		Triangle t = new Triangle(p1, p2, p3);
		System.out.println(t);
		
		System.out.println("\np1.translate(-1, 0)");
		p1.translate(-1, 0);
		System.out.println(p1);
		System.out.println(t);
		
		System.out.println("\nt.translate(1, 1)");
		t.translate(1, 1);
		System.out.println(t);
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
	}
}

/* Output:
	$ java Main 
	Triangle[(0.0, 0.0)->(0.0, 1.0)->(1.0, 0.0)]

	p1.translate(-1, 0)
	(-1.0, 0.0)
	Triangle[(0.0, 0.0)->(0.0, 1.0)->(1.0, 0.0)]

	t.translate(1, 1)
	Triangle[(1.0, 1.0)->(1.0, 2.0)->(2.0, 1.0)]
	(-1.0, 0.0)
	(0.0, 1.0)
	(1.0, 0.0)
*/
