import java.util.Vector;
//https://docs.oracle.com/javase/8/docs/api/java/util/Vector.html

//can also use java.util.ArrayList (roughly equivalent to Vector, except that it is unsynchronized.)
//https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html

public class Main {
	public static void main(String[] args) {
		Vector<Warrior> v = new Vector<Warrior>();
		/*Ninja n1 = new Ninja("Ninja1");
		Ninja n2 = new Ninja("Ninja2");

		Samurai s1 = new Samurai*/
		
		v.add(new Ninja("Ninja1"));
		v.add(new Ninja("Ninja2"));
		
		v.add(new Samurai("Samurai1"));
		v.add(new Samurai("Samurai2"));
		
		for(int i=0; i < v.size(); i++) {
			v.get(i).attack();
		}
	}
}

/* Output:
	$ java Main
	Ninja Ninja1 attacks.
	Ninja Ninja2 attacks.
	Samurai Samurai1 attacks.
	Samurai Samurai2 attacks.
*/