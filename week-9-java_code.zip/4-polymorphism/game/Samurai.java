public class Samurai extends Warrior {
	public Samurai(String name) {
		super(name);
	}
	
	//implementation of the abstract method attack(), inherited from Warrior
	public void attack() {
		System.out.println("Samurai " + this.name + " attacks.");
	}
}