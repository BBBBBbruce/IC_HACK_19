public class Ninja extends Warrior {
	public Ninja(String name) {
		super(name);
	}
	
	//implementation of the abstract method attack(), inherited from Warrior
	public void attack() {
		System.out.println("Ninja " + this.name + " attacks.");
	}
}