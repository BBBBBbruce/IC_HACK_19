public abstract class Warrior {
	public abstract void attack(); //abstract method
	
	protected String name;
	
	public Warrior(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
}