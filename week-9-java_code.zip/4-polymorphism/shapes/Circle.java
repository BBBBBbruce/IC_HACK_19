public class Circle extends Shape {
	private Point centre;
	private double radius;
	
	public Circle() {
		this(new Point(), 1);
	}
	
	public Circle(Point centre, double radius) {
		this.centre = centre;
		this.radius = radius;
	}
	
	//getters
	//...
	
	//setters
	//...

	public double perimeter() {
		return(2 * Math.PI * radius);
	}
	
	public double area() {
		return(Math.PI * Math.pow(radius, 2));
	}
	
	public String toString() {
		return("Circle[" + this.centre + ", " + this.radius + "]");
	}
}