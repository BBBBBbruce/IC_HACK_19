import java.util.Vector;

public class Main {
	public static void main(String[] args) {
		Vector<Shape> v = new Vector<Shape>();
		
		Shape s1 = new Circle();
		Shape s2 = new Rectangle();
		v.add(s1);
		v.add(s2);
		
		for(int i=0; i < v.size(); i++) {
			System.out.println("\n" + v.get(i));

			System.out.println("perimeter = " + v.get(i).perimeter());
			System.out.println("area = " + v.get(i).area());
		}
	}
}

/* Output:
	$ java Main

	Circle[(0.0, 0.0), 1.0]
	perimeter = 6.283185307179586
	area = 3.141592653589793

	Rectangle[(0.0, 0.0), 1.0, 1.0]
	perimeter = 4.0
	area = 1.0
*/