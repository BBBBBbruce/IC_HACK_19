public class Rectangle extends Shape {
	private Point topLeftCorner;
	private double width;
	private double height;
	
	public Rectangle() {
		this(new Point(), 1, 1);
	}
	
	public Rectangle(Point topLeftCorner, double width, double height) {
		this.topLeftCorner = topLeftCorner;
		this.width = width;
		this.height = height;
	}
	
	//getters
	//...
	
	//setters
	//...

	public double perimeter() {
		return(2*(width + height));
	}

	public double area() {
		return(width * height);
	}
	
	public String toString() {
		return("Rectangle[" + this.topLeftCorner + ", " + this.width + ", " + this.height + "]");
	}
}