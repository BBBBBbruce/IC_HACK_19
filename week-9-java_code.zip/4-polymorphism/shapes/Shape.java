public abstract class Shape { //can also be defined as an interface
	public abstract double perimeter();
	public abstract double area();
}