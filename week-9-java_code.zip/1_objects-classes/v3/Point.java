import java.lang.Math; //for sqrt() and pow()
//API: https://docs.oracle.com/javase/10/docs/api/java/lang/Math.html

/**
* The class Point models a 2D point in a cartesian plan having two coordinates x and y.
* A point can be translated, and can calculate its distance to another point.
* @author Sahbi Ben Ismail
* @version 1.0
* @since Autumn Term 2018-19 (EE2-12)
*/
public class Point {
	//Fields (or UML/Attributes) (C++/Variables)
	/**
	* First coordinate (abscissa).
	*/
	private double x;
	
	/**
	* Second coordinate (ordinate).
	*/
	private double y;
	
	//Constructors
	/**
	* Constructs a point with coordinates (0.0, 0.0).
	*/	
	public Point() {
		this(0.0, 0.0);
	}
	
	/**
	* Constructs a point with two given coordinates.
	* @param x first coordinate (abscissa)
	* @param y second coordinate (ordinate)
	*/
	public Point(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	//Methods (or UML/Operations) (C++/Functions)
	/**
	* Returns the first coordinate this.x (abscissa).
	* @return x 
	*/
	public double getX() {
		return x; //or return this.x;
	}
	
	/**
	* Modifies the value of the first coordinate this.x (abscissa).
	* @param x the new value of this.x
	*/	
	public void setX(double x)  {
		this.x = x;
	}
	
	/**
	* Returns the second coordinate this.y (ordinate).
	* @return y 
	*/
	public double getY() {
		return y; //or return this.y;
	}

	/**
	* Modifies the value of the second coordinate this.y (ordinate).
	* @param y the new value of this.y
	*/	
	public void setY(double y)  {
		this.y = y;
	}
	
	
	/**
	* Translates the point.
	* @param deltaX translation on the x axis
	* @param deltaY translation on the y axis
	*/
	public void translate(double deltaX, double deltaY) {
		x += deltaX;
		y += deltaY;
	}
	
	/**
	* Returns the distance between the current point and another one.
	* @param other point to which the distance is calculated
	* @return distance the calculated distance
	*/	
	public double distanceTo(Point other) {
		double deltaX = this.x - other.x;
		double deltaY = this.y - other.y;
		double distance = Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaY, 2));
		
		return(distance);
	}
	
	/**
	* Returns the distance between the current point and the origin point (0.0, 0.0).
	* @return the calculated distance
	*/	
	public double distanceToOrigin() {
		Point origin = new Point(0, 0);
		return distanceTo(origin); //or this.distanceTo(origin)
	}
	
	/**
	* Returns a description of the point.
	*/
	public String toString() {
		return("(" + x + ", " + y + ")");
	}
}


/* Ouput:
	$ mkdir doc
	$ javadoc Point.java -d doc/
	Loading source file Point.java...
	Constructing Javadoc information...
	Standard Doclet version 1.8.0_131
	Building tree for all the packages and classes...
	Generating doc\Point.html...
	Generating doc\package-frame.html...
	Generating doc\package-summary.html...
	Generating doc\package-tree.html...
	Generating doc\constant-values.html...
	Building index for all the packages and classes...
	Generating doc\overview-tree.html...
	Generating doc\index-all.html...
	Generating doc\deprecated-list.html...
	Building index for all classes...
	Generating doc\allclasses-frame.html...
	Generating doc\allclasses-noframe.html...
	Generating doc\index.html...
	Generating doc\help-doc.html...
	
	$ javadoc -author Point.java -d doc/
	...
*/