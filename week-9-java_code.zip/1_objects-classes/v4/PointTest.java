public class PointTest {
	
	public static void main(String[] args) {
	
		System.out.println("Point.nb_points = " + Point.nb_points);
		
		Point origin = new Point();
		
		System.out.println("Point.nb_points = " + Point.nb_points);
		
		Point p = new Point(1, 2);
		
		//a class field or method can be called from the class itself
		//or from any other instanciated object
		System.out.println("Point.nb_points = " + Point.nb_points);
		System.out.println("Point.nb_points = " + origin.nb_points);
		System.out.println("Point.nb_points = " + p.nb_points);
		
		/* other examples of static fields/methods:
		class Math: https://docs.oracle.com/javase/10/docs/api/java/lang/Math.html
		Math.PI, Math.E
		Math.abs(), Math.min(), Math.max(), Math.sqrt(), Math.pow();
		
		class System: https://docs.oracle.com/javase/10/docs/api/java/lang/System.html#out
		System.out in System.out.println() (out is a static field of type PrintStream)
		
		class String: https://docs.oracle.com/javase/10/docs/api/java/lang/String.html
		*/
	}
}

/* Output:
	$ java PointTest
	Point.nb_points = 0
	Point.nb_points = 1
	Point.nb_points = 2
	Point.nb_points = 2
	Point.nb_points = 2
*/
