public class Point {
	private double x;
	private double y;
	
	public Point() {
		this(0.0 ,0.0);
	}
	
	public Point(double x_in, double y_in) {
		x = x_in;
		y = y_in;
	}
	

	
	public String toString() {
		return("(" + x + ", " + y + ")");
	}
}