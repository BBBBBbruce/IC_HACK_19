//no need to import class Point
//(files Point.java and PointTest.java are in the same folder)

public class PointTest {
	
	public static void main(String[] args) {
		Point p1 = new Point(1, 2);
		System.out.println(p1.toString());
		System.out.println(p1); //toString() inherited from class java.lang.Object
		
		//System.out.println("Point p1: " + p1.toString());
		System.out.println("Point p1: " + p1);		
		System.out.println("distanceTo(p1): " + p1.distanceTo(p1));
		
		p1.translate(2, 2);
		
		//System.out.println("after translate(2, 2): " + p1.toString());
		System.out.println("after translate(2, 2): " + p1);
		System.out.println("distanceToOrigin(): " + p1.distanceToOrigin());
		
		Point p2 = new Point(4, 4);
		
		System.out.println("p1.distanceTo(p2): " + p1.distanceTo(p2));
		System.out.println("p2.distanceTo(p1): " + p2.distanceTo(p1));
	}
}

/* Output:
	$ java PointTest
	(1.0, 2.0)
	(1.0, 2.0)
	Point p1: (1.0, 2.0)
	distanceTo(p1): 0.0
	after translate(2, 2): (3.0, 4.0)
	distanceToOrigin(): 5.0
	p1.distanceTo(p2): 1.0
	p2.distanceTo(p1): 1.0
*/