#v1
basic class Point
Java API https://docs.oracle.com/javase/10/docs/api/

#v2
this: attributes or methods (including constructors) - this.x, this.distanceTo(), this()
toString(): method overriding (inherited from base class java.lang.Object)

#v3
javadoc comments


#v4
class attributes/methods (static)


#v5
equals() and compareTo()
