import java.lang.Math; //for sqrt() and pow()
//API: https://docs.oracle.com/javase/10/docs/api/java/lang/Math.html

public class Point {
	//Fields (or UML/Attributes) (C++/Variables)
	private double x;
	private double y;
	
	//Constructor
	public Point(double x_in, double y_in) {
		x = x_in;
		y = y_in;
	}
	
	//Methods (or UML/Operations) (C++/Functions)
	public double getX() {
		return x;
	}
	
	public void setX(double x_in)  {
		x = x_in;
	}
	
	public double getY() {
		return y;
	}
	
	public void setY(double y_in)  {
		y = y_in;
	}
	
	public void translate(double deltaX, double deltaY) {
		x += deltaX;
		y += deltaY;
	}
	
	public double distanceTo(Point other) {
		double deltaX = x - other.x;
		double deltaY = y - other.y;
		double distance = Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaY, 2));
		
		return(distance);
	}
	
	public double distanceToOrigin() {
		Point origin = new Point(0, 0);
		return distanceTo(origin);
	}
	
	public boolean equals(Point p){
		return (x == p.x) && (y == p.y);
	}
	
	public String toString() {
		return("(" + x + ", " + y + ")");
	}
}
